//
//  Examples.h
//  PathTracer
//
//  Created by HYZ on 2018/3/18.
//  Copyright © 2018年 HYZ. All rights reserved.
//

#ifndef Examples_h
#define Examples_h

void cbox();
void veach();
void objTest();
void test();


#endif /* Examples_h */
